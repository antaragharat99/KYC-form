<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		
		<script>
			$(document).ready(function(){
				$("#submit").click(function(){
					var fname = $("#fname").val();
					var lname = $("#lname").val();
					var mobile_no = $("#mobile_no").val();
					var imgname  =  $('#aadhar_card').val();
					var size  =  $('#aadhar_card')[0].files[0].size;

					if(!fname.match(/^[a-zA-Z]+$/) || fname.length == 0){
						alert("First name please use alphabets only");
						$("#fname").focus();
						return false;
					}
					if(!lname.match(/^[a-zA-Z]+$/) || lname.length == 0){
						alert("Last name please use alphabets only");
						$("#lname").focus();
						return false;
					}
					if(!mobile_no.match(/^[0-9]+$/) || mobile_no.length == 0){
						alert("Please enter a only number");
						$("#mobile_no").focus();
						return false;
					}
					
					var	date  = $("#dob").val(),
					year      = date.match(/\d{4}/),
					extract   = date.replace(year,'').match(/(\d+)/g);

					  if(date && year && year[0] >= 1977 && year[0] <= 1999 && new Date(extract[1]+'/'+extract[0]+'/'+year[0]) != 'Invalid Date')
					  {}
					  else
					  {
						alert('Invalid date of birth');
						$("#dob").focus();
						return false;
					  }					
				});
			
			});
		</script>
	</head>
	<body>
		<div class="container">
			<div class="col-md-6 col-md-offset-4">
				<h2>KYC Form</h2><br/>
			</div>
			<form action="data.php" method="post" enctype="multipart/form-data">
				<div class="container">
					<div class="form-group col-md-12">
						<div class="col-md-offset-2 col-md-2">
							<label for="fname">First Name:</label>
						</div>
						<div class="col-md-6">
							<input type="text" class="form-control" id="fname" name="fname" maxlength="30">
						</div>
					</div>
					<div class="form-group col-md-12">
						<div class="col-md-offset-2 col-md-2">
							<label for="lname">Last Name:</label>
						</div>
						<div class="col-md-6">
							<input type="text" class="form-control" id="lname" name="lname" maxlength="25">
						</div>
					</div>
					<div class="form-group col-md-12">
						<div class="col-md-offset-2 col-md-2">
							<label for="mobile_no">Mobile No.:</label>
						</div>
						<div class="col-md-6">
							<input type="text" class="form-control" id="mobile_no" name="mobile_no" maxlength="10">
						</div>
					</div>
					<div class="form-group col-md-12">
						<div class="col-md-offset-2 col-md-2">
							<label for="dob">Date of Birth:</label>
						</div>
						<div class="col-md-6">
							<input type="text" class="form-control datepicker" id="dob" name="dob" onsubmit="validateDate()">
						</div>
					</div>
					<div class="form-group col-md-12">
						<div class="col-md-offset-2 col-md-2">
							<label for="aadhar_card">Aadhar Card:</label>
						</div>
						<div class="col-md-6">
							<input type="file" class="form-control" id="aadhar_card" name="aadhar_card">
						</div>
					</div>
					<div class="form-group col-md-12">
						<div class="col-md-offset-2 col-md-2">
							<label for="pan_card">PAN Card:</label>
						</div>
						<div class="col-md-6">
							<input type="file" class="form-control" id="pan_card" name="pan_card">
						</div>
					</div>
					<div class="form-group col-md-12">
						<div class="col-md-offset-5 col-md-2">
							<button type="submit" id="submit" class="btn btn-info">Submit</button>
						</div>
					</div>
				</div> 
			</form>
		</div>
	</body>
</html>