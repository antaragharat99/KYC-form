<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kyc_data";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$fname = $_POST["fname"];
$lname = $_POST["lname"];
$mobile_no = $_POST["mobile_no"];
$dob = $_POST["dob"];

$target_dir = "uploads/";
$aadhar_card_img = $target_dir . basename($_FILES["aadhar_card"]["name"]);
$imageFileType = pathinfo($aadhar_card_img,PATHINFO_EXTENSION);
if($imageFileType=='jpg' || $imageFileType=='jpeg' || $imageFileType=='png' || $imageFileType=='gif')
{
	if($_FILES['aadhar_card']['size'] > 2097152){
		if (move_uploaded_file($_FILES["aadhar_card"]["tmp_name"], $aadhar_card_img)) {
				echo "The file ". basename( $_FILES["aadhar_card"]["name"]). " has been uploaded.";
			} else {
				echo "Sorry, there was an error uploading aadhar card.";
			}
		}
	else{
		echo "Pan card image size should be less than 2 MB";
	}
}


$pan_card_img= $target_dir . basename($_FILES["pan_card"]["name"]);
$imageType = pathinfo($pan_card_img,PATHINFO_EXTENSION);
if($imageType=='jpg' || $imageType=='jpeg' || $imageType=='png' || $imageType=='gif')
{
	if($_FILES['pan_card']['size'] > 2097152){
		if (move_uploaded_file($_FILES["pan_card"]["tmp_name"], $pan_card_img)) {
			echo "The file ". basename( $_FILES["pan_card"]["name"]). " has been uploaded.";
		} else {
			echo "Sorry, there was an error uploading pan card.";
		}
	}
	else{
		echo "Pan card image size should be less than 2 MB";
	}
}

$sql = "INSERT INTO kyc_detail (fname, lname, mobile_no, dob, aadhar_card, pan_card)VALUES ('$fname', '$lanme', '$mobile_no', '$dob', '$aadhar_card_img', '$pan_card_img')";

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>